export const PORT = 5555;

export const mongoDBURL =
  'mongodb+srv://dave1:dave.1146@book-store-mern.gnqo5oj.mongodb.net/';
